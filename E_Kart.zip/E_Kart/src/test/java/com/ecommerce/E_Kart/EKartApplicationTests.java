package com.ecommerce.E_Kart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EKartApplicationTests {

	@Test
	void contextLoads() {
	}

}
