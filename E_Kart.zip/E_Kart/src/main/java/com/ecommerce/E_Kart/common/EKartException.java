package com.ecommerce.E_Kart.common;

public class EKartException extends Exception{
	public EKartException(String message) {
		super(message);
	}
}
