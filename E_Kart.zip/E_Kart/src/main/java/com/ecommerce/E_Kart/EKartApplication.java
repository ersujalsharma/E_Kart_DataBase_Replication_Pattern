package com.ecommerce.E_Kart;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ecommerce.E_Kart.common.ProductDTO;
import com.ecommerce.E_Kart.common.ProductService;

@SpringBootApplication
public class EKartApplication implements CommandLineRunner{

	@Autowired
	ProductService productService;
	
	public static void main(String[] args) {
		SpringApplication.run(EKartApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		ProductDTO productDTO = new ProductDTO();
		productDTO.setProduct_name("Sujal");
		productDTO.setProduct_type("Insaan");
		productDTO.setProduct_price(1);
		Integer id = productService.addProduct(productDTO);
		System.out.println(id+" ");
		List<ProductDTO> list = productService.getProducts();
		System.out.println(list);
		
	}

}
