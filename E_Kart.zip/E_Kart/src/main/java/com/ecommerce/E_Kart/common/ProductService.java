package com.ecommerce.E_Kart.common;

import java.util.List;

public interface ProductService {
	public Integer addProduct(ProductDTO p) throws EKartException;
	public void deleteProduct(Integer id);
	public void updateProduct(Integer id, Integer price);
	public List<ProductDTO> getProducts();
}
