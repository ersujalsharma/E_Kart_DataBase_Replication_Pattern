package com.ecommerce.E_Kart.slave.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ecommerce.E_Kart.slave.entity.ProductsSlave;
@Repository(value = "slaverepo")
public interface SlaveProductRepository extends JpaRepository<ProductsSlave, Integer>{

}
