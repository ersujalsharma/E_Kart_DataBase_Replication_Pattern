package com.ecommerce.E_Kart.master.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ecommerce.E_Kart.master.entity.ProductsMaster;
@Repository(value = "masterrepo")
public interface MasterProductRepository extends JpaRepository<ProductsMaster, Integer>{

}
