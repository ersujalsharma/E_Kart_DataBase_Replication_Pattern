package com.ecommerce.E_Kart.common;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.E_Kart.master.entity.ProductsMaster;
import com.ecommerce.E_Kart.master.repo.MasterProductRepository;
import com.ecommerce.E_Kart.slave.entity.ProductsSlave;
import com.ecommerce.E_Kart.slave.repo.SlaveProductRepository;
@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	MasterProductRepository masterrepo;
	@Autowired
	SlaveProductRepository slaverepo;
	
	@Override
	public Integer addProduct(ProductDTO p) throws EKartException {
		Optional<ProductsSlave> op = slaverepo.findById(p.getProduct_id());
		if(op.isPresent()) throw new EKartException("ALREADY EXIST");
		ProductsMaster product = new ProductsMaster(0, p.getProduct_name(), p.getProduct_type(),p.getProduct_price());
		ProductsSlave productSlave = new ProductsSlave(0, p.getProduct_name(), p.getProduct_type(),p.getProduct_price());
		ProductsMaster retrieved =  masterrepo.save(product);
		slaverepo.save(productSlave);
		return retrieved.getProduct_id(); 
	}

	@Override
	public void deleteProduct(Integer id) {
		Optional<ProductsMaster> op =  masterrepo.findById(id);
		if(op.isPresent()) {
			masterrepo.deleteById(id);
			slaverepo.deleteById(id);
		}
	}

	@Override
	public void updateProduct(Integer id, Integer price) {
		Optional<ProductsMaster> op = masterrepo.findById(id);
		if(op.isPresent()) {
			ProductsMaster productMaster = op.get();
			productMaster.setProduct_price(price);
			ProductsSlave productSlave = slaverepo.findById(id).get();
			productMaster.setProduct_price(price);
			productSlave.setProduct_price(price);
		}
	}

	@Override
	public List<ProductDTO> getProducts() {
		// TODO Auto-generated method stub
		List<ProductsSlave> list = slaverepo.findAll();
		List<ProductDTO> ans = list.stream().map(t->new ProductDTO(t.getProduct_id(), t.getProduct_name(), t.getProduct_type(), t.getProduct_price())).toList();
		return ans;
	}

}
